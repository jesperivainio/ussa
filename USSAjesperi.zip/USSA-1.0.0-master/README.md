# USSA
USSA-versio kaikille

Tässä android studiosta jaettu projekti.. 

Vissii kaikkien pitäs lataa täst oma versio koneellensa jota si muokkaa ja si yhdes updatetaa tänne sitä mukaa ku saadaa valmiix... Kai...
"# ussa" 
