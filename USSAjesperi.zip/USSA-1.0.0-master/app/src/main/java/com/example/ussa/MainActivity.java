package com.example.ussa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static  final String EXTRA_TEXT="com.example.ussa.EXTRA_TEXT";
    public static final String EXTRA_TEXT1="com.example.ussa.EXTRA_TEXT1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=(Button) findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity_2();
            }

        });

        final RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        final button fiilisrate = (button) findViewById(R.id.fiilisrate);
        final TextView fiilis = (TextView) findViewById(R.id.fiilis);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fiilis.setText("Fiiliksesi on: " + ratingBar.getRating());
            }
        });


    }

    public void openactivity_2(){
        EditText editText1= (EditText) findViewById(R.id.editText1);
        String text=editText1.getText().toString();

        EditText editText2=(EditText) findViewById(R.id.editText2);
        String text1=editText2.getText().toString();

        Intent intent=new Intent(this,activity_2.class);
        intent.putExtra(EXTRA_TEXT, text);
        intent.putExtra(EXTRA_TEXT1, text1);

        startActivity(intent);
    }
}
